--- Stream for some flight instruments

local M = {}

--------------------
-- EVENT HANDLERS --
--------------------

local sensorData = {}
function M.updateGFX(dt)
    if obj and streams.willSend("av331flightinstrumentsstream") then
        local airVelocity = obj:getVelocity() - obj:getFlow()
        local roll, pitch, yaw = obj:getRollPitchYaw()
        local densityFactor = obj:getDensityAtNode(0) / 1.225
        
        sensorData.delta = dt
        sensorData.trueAirspeed = airVelocity:length()
        sensorData.densityFactor = densityFactor
        -- based on official IndicatedAirspeed
        sensorData.indicatedAirspeed = math.sqrt(airVelocity:squaredLength() * densityFactor)
        sensorData.verticalSpeed = airVelocity.z
        sensorData.isUpsideDown = obj:getDirectionVectorUp().z <= 0
        sensorData.yaw = yaw
        sensorData.pitch = pitch
        sensorData.roll = roll

        guihooks.send("av331flightinstrumentsstream", sensorData)
    end
end

return M
