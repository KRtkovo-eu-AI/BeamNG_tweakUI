angular.module('beamng.apps').directive('flightInstruments', [function () {
	/* const */ var settingsPath = "settings/ui_apps/aviator331/flightinstruments/settings.json";
    var appSettings = {};

    /* example settings.json (you can use an empty string to create an empty slot):
{
  "instruments": [
    "airspeed", "turnCoordinator", "altimeter",
    "headingIndicator", "attitudeIndicator", "variometer"
  ]
}

defaults:

{
  "instruments": [
    "airspeed", "altimeter", "attitudeIndicator",
    "turnCoordinator", "headingIndicator", "variometer"
  ]
}
     */

    // Data extraction
    // =============================================

    var bootstrapLua = `
        local flightInstrumentExtensionName = "av331flightinstruments"
        if not extensions.isExtensionLoaded(flightInstrumentExtensionName) then
            extensions.load(flightInstrumentExtensionName)
        end
    `;

    var auxiliaryDataLua = `(function ()
        local airVelocity = obj:getVelocity() - obj:getFlow()
        local roll, pitch, yaw = obj:getRollPitchYaw()
        local densityFactor = obj:getDensityAtNode(0) / 1.225
        return { 
            trueAirspeed = airVelocity:length(),
            densityFactor = densityFactor,
            -- based on official IndicatedAirspeed
            indicatedAirspeed = math.sqrt(airVelocity:squaredLength() * densityFactor),
            verticalSpeed = airVelocity.z,
            isUpsideDown = obj:getDirectionVectorUp().z <= 0,
            yaw = yaw,
            pitch = pitch,
            roll = roll
        }
    end)()`;

    var findSeaLevelLua = `(function ()
        local water = scenetree.findObject("Ocean")
        if not water then
            local objects = scenetree.findClassObjects("WaterPlane")
            for _, name in pairs(objects) do
                local obj = scenetree.findObject(name)
                if string.find(name, "Ocean") then
                    water = obj
                    break
                end
            end
        end

        if water then
            return water.position:getColumn(3).z
        else
            return 0
        end
    end)()`;

    function clamp(v, vMin, vMax) {
        return Math.max(vMin, Math.min(vMax, v));
    }

    function wrapAngleInDegrees(angle) {
        return angle < 0 ? angle + 360 : angle;
    }

    function normalizeHeadingDifference(angle) {
        if (angle > 180) return angle - 360;
        if (angle < -180) return angle + 360;
        return angle;
    }

    function getSensorData(target, sensors) {
        // indicated airspeed is computed elsewhere
        
        // pitch as degrees, + points nose up, - points nose down
        target.attitudePitch = Math.asin(sensors.pitch) * 180 / Math.PI;
        // bank as degrees, + is clockwise
        target.attitudeBankRaw = -Math.asin(sensors.roll) * 180 / Math.PI;

        // altitude in meters, positive above sea level
        target.altitudeRaw = sensors.position.z;

        // heading as degrees clockwise from north = 0
        target.heading = wrapAngleInDegrees(-sensors.yaw * 180 / Math.PI);

        // vertical speed is computed elsewhere

        // accelerometers
        target.accelX = sensors.gx2;
        target.accelY = sensors.gy2;
        target.accelZ = sensors.gz2;
        target.gravity = -sensors.gravity;
    }

    function getElectricsData(target, electrics) {
        // airspeed
        target.airspeed = electrics.airflowspeed;

        // altitude in meters, positive above sea level
        target.altitude = electrics.altitude;
    }

    // Data processing
    // =============================================

    function smoothFilter(oldValue, newValue, delta, responseSpeed) {
        if (adjustedDelta > 1000) return newValue;
        var adjustedDelta = delta * responseSpeed;
        var mexp = Math.exp(-adjustedDelta);
        return oldValue * mexp + newValue * (1 - mexp);
    }

    class Smoother {
        constructor(responseSpeed) {
            this._responseSpeed = responseSpeed;
            this._value = null;
        }

        update(delta, value) {
            if (Number.isFinite(value)) {
                if (this._value == null) {
                    this._value = value;
                } else if (delta > 0) {
                    this._value = smoothFilter(this._value, value, delta, this._responseSpeed);
                }
            }
            return this._value;
        }

        value() {
            return this._value || 0;
        }

        reset() {
            this._value = null;
        }
    }

    // Layout
    // =============================================

    var SUPPORTED_INSTRUMENTS = new Set([
        "airspeed",
        "altimeter",
        "attitudeIndicator",
        "turnCoordinator",
        "headingIndicator",
        "variometer",
    ]);
    var instrumentDisplayPrefixes = {
        attitudeIndicator: "Pitch: ",
        turnCoordinator: "Bank: ",
    };
    var instrumentDisplaySuffixes = {
        airspeed: " kt",
        altimeter: " ft",
        attitudeIndicator: " \u00b0",
        turnCoordinator: " \u00b0",
        headingIndicator: " \u00b0",
        variometer: " ft/min",
    };

    function makeInstrumentPanel(kind) {
        if (!kind) return `<div class="av331-panel-parent"></div>`;
        return `
            <div id="av331-instrument-${kind}-parent" class="av331-panel-parent">
                <div class="av331-panel-analog">
                    <object id="av331-instrument-${kind}-svg" type="image/svg+xml" data="/ui/modules/apps/Av331FlightInstruments/${kind}.svg"></object>
                </div>
                <div class="av331-panel-digital">${instrumentDisplayPrefixes[kind] || ''}<span class="av331-panel-digital-value" id="av331-instrument-${kind}-digital">------</span>${instrumentDisplaySuffixes[kind] || ''}</div>
            </div>
        `;
    }

    // Smoothers
    // =============================================

    var smootherIndicatedAirspeed = new Smoother(150);
    var smootherAltitude = new Smoother(150);
    var smootherPitch = new Smoother(250);
    var smootherRateOfTurn = new Smoother(20);
    var smootherSlipG = new Smoother(40);
    var smootherVerticalSpeed = new Smoother(10);

    function resetSmoothers() {
        smootherIndicatedAirspeed.reset();
        smootherAltitude.reset();
        smootherPitch.reset();
        smootherRateOfTurn.reset();
        smootherSlipG.reset();
        smootherVerticalSpeed.reset();
    }

    function computeInstrumentData(instrumentData, data, delta) {
        instrumentData.indicatedAirspeed = smootherIndicatedAirspeed.update(delta, data.indicatedAirspeed);
        instrumentData.altitude = smootherAltitude.update(delta, data.altitude);
        instrumentData.pitch = smootherPitch.update(delta, data.attitudePitch);
        instrumentData.bank = data.attitudeBank;
        instrumentData.heading = data.heading;
        instrumentData.rateOfTurn = smootherRateOfTurn.update(delta, data.rateOfTurn);
        instrumentData.slipG = smootherSlipG.update(delta, data.slipG);
        instrumentData.verticalSpeed = smootherVerticalSpeed.update(delta, data.verticalSpeed);

        instrumentData.slipDegrees = Math.atan(instrumentData.slipG) * 180 / Math.PI;
    }

    // Instrument code
    // =============================================

    var svgCache = new WeakMap();

    var INSTRUMENTS = ['airspeed', 'attitudeIndicator', 'altimeter', 'turnCoordinator', 'headingIndicator', 'variometer'];

    /* const */ var KNOTS_IN_METERS_PER_SECOND = 1.94384449;
    /* const */ var FEET_PER_MINUTE_IN_METERS_PER_SECOND = 196.850394;
    /* const */ var FEET_IN_METERS = 3.2808399;

    function resolveById(svg, id) {
        var cache = svgCache.get(svg);
        var result = cache && cache[id];

        if (cache && !result) {
            result = svg.getElementById(id);
            cache[id] = result;
        }

        return result;
    }

    function formatNumber(value, intDigits, fracDigits, padChar, signed) {
        intDigits = intDigits || 0;
        fracDigits = fracDigits || 0;
        padChar = padChar || '\u00a0';
        sign = '';
        
        if (value < 0) {
            sign = '-';
            value = -value;
        } else if (signed) {
            sign = '\u00a0';
        }

        var strValue = value.toFixed(fracDigits);
        var expectedLength = fracDigits > 0 ? intDigits + fracDigits + 1 : intDigits;
        return sign + strValue.padStart(expectedLength, padChar);
    }

    function updateAirspeed(data, svgList, digital) {
        var kIAS = data.indicatedAirspeed * KNOTS_IN_METERS_PER_SECOND;

        for (var svg of svgList) {
            var pointer = resolveById(svg, 'pointer');

            if (pointer) {
                var angle;
                var TO40 = 14;
                var PAST40 = 36;
                if (kIAS < 40) {
                    angle = kIAS / 40;
                    angle *= angle * TO40;
                } else {
                    angle = TO40 + PAST40 * ((kIAS - 40) / 20);
                }
                pointer.style.transform = `rotate(${angle}deg)`;
            }
        }

        if (digital) digital.textContent = formatNumber(kIAS, 4, 2);
    }

    function updateAltimeter(data, svgList, digital) {
        var ftA = data.altitude * FEET_IN_METERS;

        for (var svg of svgList) {
            var ft100 = resolveById(svg, 'ft100');
            if (ft100) ft100.style.transform = `rotate(${ftA * 0.36}deg)`;

            var ft1k = resolveById(svg, 'ft1k');
            if (ft1k) ft1k.style.transform = `rotate(${ftA * 0.036}deg)`;

            var ft10k = resolveById(svg, 'ft10k');
            if (ft10k) ft10k.style.transform = `rotate(${ftA * 0.0036}deg)`;
        }

        if (digital) digital.textContent = formatNumber(ftA, 5, 1);
    }

    function updateAttitudeIndicator(data, svgList, digital) {
        for (var svg of svgList) {
            var NOTCH_HEIGHT = 20;
            var horizonTranslate = data.pitch * NOTCH_HEIGHT / 10;

            var horizon = resolveById(svg, 'horizon');
            if (horizon) horizon.style.transform = `translate(0px, ${horizonTranslate}px)`;

            var bank = resolveById(svg, 'bank');
            if (bank) bank.style.transform = `translate(0px, ${-horizonTranslate}px) rotate(${-data.bank}deg) translate(0px, ${horizonTranslate}px)`;

            var wheel = resolveById(svg, 'wheel');
            if (wheel) wheel.style.transform = `rotate(${-data.bank}deg)`;            
        }

        if (digital) digital.textContent = formatNumber(data.pitch, 2, 2, null, true);
    }

    function updateTurnCoordinator(data, svgList, digital) {
        for (var svg of svgList) {
            var rateOfTurn = data.rateOfTurn;

            var plane = resolveById(svg, 'plane');
            if (plane) {
                var rollAngle = data.bank;
                var turnAngle = clamp(rateOfTurn * 20 / 3 * 0.634 + rollAngle * 0.366, -60, 60);
                plane.style.transform = `rotate(${turnAngle}deg)`;
            }

            var slip = resolveById(svg, 'slip');
            if (slip) {
                var slipAngle = clamp(data.slipDegrees, -15, 15);
                slip.style.transform = `rotate(${slipAngle}deg)`;
            }
        }

        if (digital) digital.textContent = formatNumber(data.bank, 3, 2, null, true);
    }

    function updateHeadingIndicator(data, svgList, digital) {
        var correctedHeading = wrapAngleInDegrees(data.heading - 180);

        for (var svg of svgList) {
            var circle = resolveById(svg, 'circle');
            if (circle) circle.style.transform = `rotate(${-correctedHeading}deg)`;
        }

        if (digital) digital.textContent = formatNumber(correctedHeading, 3, 2, '0');
    }

    function updateVariometer(data, svgList, digital) {
        var vasi = data.verticalSpeed * FEET_PER_MINUTE_IN_METERS_PER_SECOND;

        for (var svg of svgList) {
            var pointer = resolveById(svg, 'vasi');
            if (pointer) pointer.style.transform = `rotate(${vasi * 0.072}deg)`;
        }

        if (digital) digital.textContent = formatNumber(vasi, 5, 0, null, true);
    }
    
    function validateInstruments(instruments) {
        var validatedInstruments = [];
        var duplicateInstruments = new Set();
        var MAXIMUM_INSTRUMENTS = 6;

        for (var instrument of instruments) {
            if (instrument) {
                if (!SUPPORTED_INSTRUMENTS.has(instrument)) {
                    console.warn(`ignoring unsupported instrument '${instrument}'`);
                    continue;
                }
                if (duplicateInstruments.has(instrument)) {
                    console.warn(`ignoring duplicate instrument '${instrument}'`);
                    continue;
                }
                duplicateInstruments.add(instrument);
            }
            validatedInstruments.push(instrument || "");
            if (validatedInstruments.length > MAXIMUM_INSTRUMENTS) {
                console.warn(`ignoring further instruments, already have ${MAXIMUM_INSTRUMENTS}`);
                break;
            }
        }

        return validatedInstruments;
    }

    function makeInstruments(instruments) {
        return validateInstruments(instruments).map(instrument => makeInstrumentPanel(instrument)).join('');
    }
    var html = `<div style="width:100%; height:100%; box-sizing:border-box;" class="bngApp aviator331-FlightInstruments">
            <link type="text/css" rel="stylesheet" href="/ui/modules/apps/Av331FlightInstruments/app.css">
            <div class="av331-main-panel" id="av331-instruments-main-panel">
                ${makeInstruments(INSTRUMENTS)}
            </div>
        </div>`;

    // Entry point
    // =============================================

    return {
        template: html,
        replace: true,
        restrict: 'EA',
        link: function (scope, element, attrs) {
            var streamsList = ['sensors', 'electrics', 'av331flightinstrumentsstream'];

            StreamsManager.add(streamsList);

            scope.$on('$destroy', function () {
                // bngApi.engineLua('jsonWriteFile(' + bngApi.serializeToLua(settingsPath) + ', ' + bngApi.serializeToLua(appSettings) + ', ' + bngApi.serializeToLua(true) + ')');
                StreamsManager.remove(streamsList);
            });

            var parent = null;
            var paused = false;
            var switched = false;
            var inReplay = false;
            var replayPaused = false;
            var replaySkip = false;
            var lastReplayElapsed = 0;
            var seaLevel = 0;
            var lastYaw = null;

            var svgs = {};
            var digitals = {};

            // try to find sea level
            bngApi.engineLua(findSeaLevelLua, (initialSeaLevel) => seaLevel = initialSeaLevel);

            function addSvgForInstrument(instrument, svg) {
                svgs[instrument].push(new WeakRef(svg));
                svgCache.set(svg, {});
            }
            
            function onReset() {
                lastYaw = null;
                resetSmoothers();
            }

            // boot up VLUA for instruments
            bngApi.activeObjectLua(bootstrapLua);
            onReset();
            scope.$on("VehicleReset", function (_, data) {
                bngApi.activeObjectLua(bootstrapLua);
                onReset();
                switched = true;
            });
            scope.$on("VehicleChange", function (_, data) {
                bngApi.activeObjectLua(bootstrapLua);
                onReset();
                switched = true;
            });
            scope.$on("VehicleFocusChanged", function (_, data) {
                bngApi.activeObjectLua(bootstrapLua);
                onReset();
                switched = true;
            });

            function discoverSvg(instrument) {
                var svg = parent.querySelector(`#av331-instrument-${instrument}-svg`);
                if (svg) {
                    angular.element(svg).on('load', function() {
                        addSvgForInstrument(instrument, svg.contentDocument);
                    });

                    if (svg.contentDocument) {
                        addSvgForInstrument(instrument, svg.contentDocument);
                    }
                } else {
                    // element not truly ready yet
                    setTimeout(function () { discoverSvg(instrument); }, 100);
                }
            }

            function rediscoverElements() {
                for (var instrument of INSTRUMENTS) {
                    svgs[instrument] = [];
                    digitals[instrument] = parent.querySelector(`#av331-instrument-${instrument}-digital`);
                    discoverSvg(instrument);
                }
            }

            bngApi.engineLua('jsonReadFile(' + bngApi.serializeToLua(settingsPath) + ')', (settings) => {
                appSettings = settings || {};
                if (appSettings.instruments) {
                    var parentPanel = parent.querySelector('#av331-instruments-main-panel');
                    if (parentPanel) {
                        parentPanel.innerHTML = makeInstruments(appSettings.instruments);
                        rediscoverElements();
                    }
                }
            });

            var lastNow = null;
            var timeScale = 0;

            element.ready(function () {
                parent = element[0];
                rediscoverElements(parent);
            });
            element.on("load", function () {
                parent = element[0];
                rediscoverElements(parent);
            });

            function updateInstrument(fn, name, data) {
                fn(data, (svgs[name] || []).map(ref => ref.deref()).filter(x => x != null), digitals[name]);
            }

            function isInReplay(replayState) {
                return replayState && replayState.state != "inactive" && replayState.state != "recording";
            }

            function updateReplayState(replayState) {
                var wasInReplay = inReplay;
                inReplay = isInReplay(replayState);
                if (inReplay) {
                    replayPaused = !!replayState.paused;
                    replaySkip = replaySkip || Math.abs(replayState.positionSeconds - lastReplayElapsed) > 1;
                    lastReplayElapsed = replayState.positionSeconds;
                } else {
                    replaySkip = false;
                }
                switched = switched || wasInReplay != inReplay;
            }

            scope.$on('physicsStateChanged', function (event, running) {
                paused = !running;
            });
            scope.$on('replayStateChanged', function (event, val) {
                updateReplayState(val);
            });
            // initial pause and replay state
            bngApi.engineLua("simTimeAuthority.getPause()",
                (isPaused) => {
                    paused = isPaused;
                });
            scope.$emit('requestPhysicsState');
            bngApi.engineLua(`
                (function ()
                    if extensions.isExtensionLoaded("core_replay") then
                        return extensions.core_replay.state
                    else
                        return nil
                    end
                end)()`,
                (replayState) => replayState && updateReplayState(replayState));
            bngApi.engineLua("(function () if be:getFileStream() then be:getFileStream():requestState() end end)()");

            var auxData = {
                trueAirspeed: 0,      // m/s
                indicatedAirspeed: 0, // m/s
                verticalSpeed: 0,     // m/s
                isUpsideDown: false,
                densityFactor: null,
                yaw: 0,
            };
        
            function readAuxiliaryData(gotAuxData) {
                auxData.trueAirspeed = gotAuxData.trueAirspeed;
                auxData.densityFactor = gotAuxData.densityFactor;
                auxData.indicatedAirspeed = gotAuxData.indicatedAirspeed;
                auxData.verticalSpeed = gotAuxData.verticalSpeed;
                auxData.isUpsideDown = gotAuxData.isUpsideDown;
                auxData.yaw = gotAuxData.yaw;
            }

            var data = {};
            var edata = {};
            var instrumentData = {};
            scope.$on('streamsUpdate', function (event, streams) {
                if (!streams.sensors || !parent || !switched && (inReplay ? replayPaused : paused)) return;

                var now = Date.now() * 1e-3;
                var delta = lastNow == null ? 0.1 : now - lastNow;
                lastNow = now;
                
                if (streams.av331flightinstrumentsstream && streams.av331flightinstrumentsstream.delta) {
                    delta = streams.av331flightinstrumentsstream.delta;
                } else {
                    bngApi.engineLua('(be:getSimulationTimeScale())',
                        function (luaData) {
                            timeScale = luaData;
                        });
                    delta *= timeScale;    
                }

                if (streams.av331flightinstrumentsstream) {
                    readAuxiliaryData(streams.av331flightinstrumentsstream);
                } else {
                    bngApi.activeObjectLua(auxiliaryDataLua,
                        function (luaData) {
                            readAuxiliaryData(luaData);
                        });
                }

                getSensorData(data, streams.sensors);

                data.trueAirspeed = auxData.trueAirspeed;
                data.indicatedAirspeed = auxData.indicatedAirspeed;

                if (streams.electrics) {
                    getElectricsData(edata, streams.electrics);
                    if (edata.altitude != null) data.altitudeRaw = edata.altitude;
                    if (edata.airspeed != null) data.trueAirspeed = edata.airspeed;
                    if (auxData.densityFactor == null)
                        // simulate altitude effects on airspeed
                        data.indicatedAirspeed = data.trueAirspeed / Math.max(0.5, 1 + (data.altitude * 6.56168e-05));
                    else
                        data.indicatedAirspeed = data.trueAirspeed * Math.sqrt(auxData.densityFactor);
                }

                if (replaySkip) {
                    resetSmoothers();
                    replaySkip = false;
                }

                data.verticalSpeed = auxData.verticalSpeed;
                data.altitude = data.altitudeRaw - seaLevel;

                var newYaw = auxData.yaw == null ? auxData.yaw * -180 / Math.PI : data.heading;
                if (lastYaw == null) {
                    data.rateOfTurn = 0;
                    lastYaw = newYaw;
                } else {
                    data.rateOfTurn = normalizeHeadingDifference(newYaw - lastYaw) / delta;
                    lastYaw = newYaw;
                }

                data.slipG = -data.accelX / Math.max(1, data.accelZ);

                // fix bank
                if (auxData.isUpsideDown) {
                    var angle = data.attitudeBankRaw;
                    angle = 180 - angle;
                    if (angle > 180) angle = angle - 360;
                    data.attitudeBank = angle;
                } else {
                    data.attitudeBank = data.attitudeBankRaw;
                }

                if (switched) {
                    delta = Number.POSITIVE_INFINITY;
                    switched = false;
                }

                computeInstrumentData(instrumentData, data, delta);
                updateInstrument(updateAirspeed, 'airspeed', instrumentData);
                updateInstrument(updateAltimeter, 'altimeter', instrumentData);
                updateInstrument(updateAttitudeIndicator, 'attitudeIndicator', instrumentData);
                updateInstrument(updateTurnCoordinator, 'turnCoordinator', instrumentData);
                updateInstrument(updateHeadingIndicator, 'headingIndicator', instrumentData);
                updateInstrument(updateVariometer, 'variometer', instrumentData);
            });
        }
    };
}])